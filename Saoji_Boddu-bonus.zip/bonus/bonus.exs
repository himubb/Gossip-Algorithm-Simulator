defmodule Bonus do
  [numnodes, topology, algorithm,err] = System.argv() |> IO.inspect()
  #extracted arguments from commandline

  numnodes = String.to_integer(numnodes)
  Registry.start_link(keys: :unique, name: :reg_name)
  err = String.to_integer(err)

  error_nodes = err * numnodes / 100 |> ceil() |> trunc()

  IO.puts(error_nodes)
  #check for algorithm gossip or pushsum and redirect aaccordingly
  if algorithm=="gossip" or algorithm == "Gossip" do
    Gossip.start(numnodes, topology,error_nodes)
  else
    if algorithm=="pushsum" or algorithm == "Pushsum" do
      Pushsum.start(numnodes, topology,error_nodes)
    else
      IO.puts("Enter correct algorithm name")
    end
  end
end
